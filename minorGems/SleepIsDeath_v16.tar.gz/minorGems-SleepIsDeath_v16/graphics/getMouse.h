// Jason Rohrer
// getMouse.h

/**
*
*	general interface for getting current mouse position
*	Implemented by a graphix framework on a particular platform
*
*
*	Created 3-21-2000
*	Mods:	
*
*/


void getMouse( int *x, int *y );